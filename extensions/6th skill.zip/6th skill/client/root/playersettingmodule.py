# Look for
NEW_678TH_SKILL_ENABLE = 0
# Modify
NEW_678TH_SKILL_ENABLE = 1

# Look for
NEW_678TH_SKILL_ENABLE = localeInfo.IsYMIR()
# Remove the line or comment it like this
# NEW_678TH_SKILL_ENABLE = localeInfo.IsYMIR()

# Look for
"SUPPORT" : (122, 123, 121, 124, 125, 129, 0, 0, 130, 131, 141, 142,),
# Modify
"SUPPORT" : (122, 123, 121, 124, 125, 129, 0, 0, 130, 131,),

# Look for again..
"SUPPORT" : (122, 123, 121, 124, 125, 129, 0, 0, 130, 131, 141, 142,),
# Modify again..
"SUPPORT" : (122, 123, 121, 124, 125, 129, 0, 0, 130, 131,),

# Look for again...
"SUPPORT" : (122, 123, 121, 124, 125, 129, 0, 0, 130, 131, 141, 142,),
# Modify again...
"SUPPORT" : (122, 123, 121, 124, 125, 129, 0, 0, 130, 131,),

# Look for again....
"SUPPORT" : (122, 123, 121, 124, 125, 129, 0, 0, 130, 131, 141, 142,),
# Modify again....
"SUPPORT" : (122, 123, 121, 124, 125, 129, 0, 0, 130, 131,),
