-- Look for
gameforge.locale.gm_skill_name_9 = "Silne Cia�o "

-- Add under
gameforge.locale.gm_skill_name_new1 = "Woli �ycia "
gameforge.locale.gm_skill_name_new2 = "Kr�gu Mieczy "
gameforge.locale.gm_skill_name_new3 = "Wolno Dzia�.Tru. "
gameforge.locale.gm_skill_name_new4 = "Iskrz�ce Uderz. "
