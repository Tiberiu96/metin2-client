-- Look for
gameforge.locale.gm_skill_name_9 = "Corpo Forte "

-- Add under
gameforge.locale.gm_skill_name_new1 = "For�a Vital "
gameforge.locale.gm_skill_name_new2 = "Orbe da Espada "
gameforge.locale.gm_skill_name_new3 = "Veneno Insidioso "
gameforge.locale.gm_skill_name_new4 = "Fa�sca "
