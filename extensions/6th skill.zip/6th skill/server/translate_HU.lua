-- Look for
gameforge.locale.gm_skill_name_9 = "Er�s test "

-- Add under
gameforge.locale.gm_skill_name_new1 = "�letenergia "
gameforge.locale.gm_skill_name_new2 = "Kardk�r "
gameforge.locale.gm_skill_name_new3 = "Alattomos m�reg "
gameforge.locale.gm_skill_name_new4 = "Szikra "
