-- Look for
gameforge.locale.gm_skill_name_9 = "Corps puissant "

-- Add under
gameforge.locale.gm_skill_name_new1 = "Volont� de vivre "
gameforge.locale.gm_skill_name_new2 = "Orbe de l'�p�e "
gameforge.locale.gm_skill_name_new3 = "Poison insidieux "
gameforge.locale.gm_skill_name_new4 = "Coup �tincelant "
