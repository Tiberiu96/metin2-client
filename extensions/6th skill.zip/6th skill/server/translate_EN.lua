-- Look for
gameforge.locale.gm_skill_name_9 = "Strong body "

-- Add under
gameforge.locale.gm_skill_name_new1 = "Life Force "
gameforge.locale.gm_skill_name_new2 = "Sword Orb "
gameforge.locale.gm_skill_name_new3 = "Insidious Poison "
gameforge.locale.gm_skill_name_new4 = "Spark "
