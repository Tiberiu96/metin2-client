-- Look for
gameforge.locale.gm_skill_name_9 = "Siln� t�lo "

-- Add under
gameforge.locale.gm_skill_name_new1 = "S�ly �ivota "
gameforge.locale.gm_skill_name_new2 = "�hnouc�ho me�e "
gameforge.locale.gm_skill_name_new3 = "Z�ludn�ho jedu "
gameforge.locale.gm_skill_name_new4 = "Jiskry "
