-- Look for
gameforge.locale.gm_skill_name_9 = "Sterk Lichaam "

-- Add under
gameforge.locale.gm_skill_name_new1 = "Levenskracht "
gameforge.locale.gm_skill_name_new2 = "Zwaard Orb "
gameforge.locale.gm_skill_name_new3 = "Verradelijk Gif "
gameforge.locale.gm_skill_name_new4 = "Vonk "
