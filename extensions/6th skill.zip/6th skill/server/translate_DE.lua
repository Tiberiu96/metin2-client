-- Look for
gameforge.locale.gm_skill_name_9 = "Starker K�rper "

-- Add under
gameforge.locale.gm_skill_name_new1 = "Lebenswille "
gameforge.locale.gm_skill_name_new2 = "Schwertzirkel "
gameforge.locale.gm_skill_name_new3 = "Schleichendes-Gift "
gameforge.locale.gm_skill_name_new4 = "Funkenschlag "
