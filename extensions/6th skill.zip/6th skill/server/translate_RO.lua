-- Look for
gameforge.locale.gm_skill_name_9 = "Corp puternic"

-- Add under
gameforge.locale.gm_skill_name_new1 = "Puterea Vietii "
gameforge.locale.gm_skill_name_new2 = "Sfera Sabiei "
gameforge.locale.gm_skill_name_new3 = "Otrava Subtila "
gameforge.locale.gm_skill_name_new4 = "Scanteie "
