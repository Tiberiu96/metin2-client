-- Look for
gameforge.locale.gm_skill_name_9 = "Corpo forte "

-- Add under
gameforge.locale.gm_skill_name_new1 = "Volont� di vivere "
gameforge.locale.gm_skill_name_new2 = "Orb della spada "
gameforge.locale.gm_skill_name_new3 = "Veleno insidioso "
gameforge.locale.gm_skill_name_new4 = "Colpo sfavillante "
