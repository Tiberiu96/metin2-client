-- Look for
gameforge.locale.gm_skill_name_9 = "Cuerpo fuerte "

-- Add under
gameforge.locale.gm_skill_name_new1 = "Deseo de vivir "
gameforge.locale.gm_skill_name_new2 = "C�rculo de espada "
gameforge.locale.gm_skill_name_new3 = "Veneno lento "
gameforge.locale.gm_skill_name_new4 = "Golpe lum�nico "
