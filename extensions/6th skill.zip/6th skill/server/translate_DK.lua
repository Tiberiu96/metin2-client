-- Look for
gameforge.locale.gm_skill_name_9 = "St�rk kroppen "

-- Add under
gameforge.locale.gm_skill_name_new1 = "Livskraft "
gameforge.locale.gm_skill_name_new2 = "Sv�rdcirkel "
gameforge.locale.gm_skill_name_new3 = "Lumsk gift "
gameforge.locale.gm_skill_name_new4 = "Gnist "
