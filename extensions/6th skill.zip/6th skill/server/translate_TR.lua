-- Look for
gameforge.locale.gm_skill_name_9 = "G��l� beden "

-- Add under
gameforge.locale.gm_skill_name_new1 = "Ya�ama �ste�i "
gameforge.locale.gm_skill_name_new2 = "K�l�� �emberi "
gameforge.locale.gm_skill_name_new3 = "Sinsi Zehir "
gameforge.locale.gm_skill_name_new4 = "K�v�lc�m Vuru�u "
