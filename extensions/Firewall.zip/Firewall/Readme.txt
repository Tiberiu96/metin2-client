1. Place the ipfw.rules to /usr/metin2

2. Open /etc/rc.conf and add this:
firewall_enable="YES"
firewall_script="/usr/metin2/ipfw.rules"

3. Reboot
