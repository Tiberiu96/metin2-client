// Look for
INVENTORY_MAX_NUM		= 90,

// Modify
INVENTORY_MAX_NUM		= 180,
