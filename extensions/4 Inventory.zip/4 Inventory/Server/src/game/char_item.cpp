// Look for
					BYTE bPage = bCell / (INVENTORY_MAX_NUM / 2);
// Modify
					BYTE bPage = bCell / (INVENTORY_MAX_NUM / 4);

// Look for (Again...)
					BYTE bPage = bCell / (INVENTORY_MAX_NUM / 2);
// Modify (Again...)
					BYTE bPage = bCell / (INVENTORY_MAX_NUM / 4);

// Look for
					if (p / (INVENTORY_MAX_NUM / 2) != bPage)
// Modify
					if (p / (INVENTORY_MAX_NUM / 4) != bPage)

// Look for (Again...)
					if (p / (INVENTORY_MAX_NUM / 2) != bPage)
// Modify (Again...)
					if (p / (INVENTORY_MAX_NUM / 4) != bPage)
