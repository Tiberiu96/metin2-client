# It is actually an unused variable, but better to modify...

# Look for
EQUIPMENT_START_INDEX = 90

# Modify
EQUIPMENT_START_INDEX = 180
