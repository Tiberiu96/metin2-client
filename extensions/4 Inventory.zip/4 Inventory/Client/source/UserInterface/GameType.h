// Look for:
const DWORD c_Inventory_Page_Count = 2;

// Then modify:
const DWORD c_Inventory_Page_Count = 4;
